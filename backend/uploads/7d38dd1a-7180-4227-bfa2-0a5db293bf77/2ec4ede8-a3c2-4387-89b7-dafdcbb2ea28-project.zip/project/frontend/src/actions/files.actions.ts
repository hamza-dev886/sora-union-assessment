"use server";

import { auth } from "@/auth";
import { env } from "@/lib/env";

export async function getFiles(folderId?: string | null) {
  const session = await auth();
  const token = session?.user?.accessToken;

  try {
    if (!token) {
      return { error: "Authentication required" };
    }

    const url = folderId ? `${env.apiUrl}/files?folderId=${folderId}` : `${env.apiUrl}/files`;

    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      next: { tags: ["files"] }, 
    });

    if (!response.ok) {
      return { error: "Failed to fetch files" };
    }

    const files = await response.json();
    return files;
  } catch (error) {
    console.error("Error fetching files:", error);
    return { error: "An unexpected error occurred" };
  }
}
