"use client";

import { FC } from "react";
import { File, FileText, FileImage, FileAudio, FileVideo } from "lucide-react";

interface FileItemProps {
  file: {
    id: string;
    name: string;
    type: string;
    size: number;
    createdAt: string;
  };
}

const FileItem: FC<FileItemProps> = ({ file }) => {
  // Format the date to a more readable format
  const formattedDate = new Date(file.createdAt).toLocaleDateString();

  // Format file size to human-readable format
  const formatFileSize = (sizeInBytes: number): string => {
    if (sizeInBytes < 1024) return `${sizeInBytes} B`;
    else if (sizeInBytes < 1024 * 1024) return `${(sizeInBytes / 1024).toFixed(1)} KB`;
    else if (sizeInBytes < 1024 * 1024 * 1024) return `${(sizeInBytes / (1024 * 1024)).toFixed(1)} MB`;
    else return `${(sizeInBytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  };

  // Get appropriate icon based on file type
  const getFileIcon = () => {
    const mimeType = file.type.toLowerCase();
    
    if (mimeType.includes('image')) {
      return <FileImage size={24} className="text-green-500" />;
    } else if (mimeType.includes('audio')) {
      return <FileAudio size={24} className="text-purple-500" />;
    } else if (mimeType.includes('video')) {
      return <FileVideo size={24} className="text-red-500" />;
    } else if (mimeType.includes('pdf') || mimeType.includes('document') || mimeType.includes('text')) {
      return <FileText size={24} className="text-orange-500" />;
    } else {
      return <File size={24} className="text-gray-500" />;
    }
  };

  return (
    <div className="p-4 border rounded-lg hover:bg-gray-50 transition-colors flex items-start space-x-4">
      <div>
        {getFileIcon()}
      </div>
      <div className="flex-1 min-w-0">
        <h3 className="font-medium text-gray-900 truncate">{file.name}</h3>
        <p className="text-sm text-gray-500">
          {formatFileSize(file.size)} • {formattedDate}
        </p>
      </div>
    </div>
  );
};

export default FileItem;