"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { getFolders, deleteFolder, renameFolder } from "@/actions/folders.actions";
import { getFiles } from "@/actions/files.actions";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import ContentListing from "@/components/drive/content-listing/content-listing";

export default function Home() {
  const { data: session } = useSession();
  const [currentFolderId, setCurrentFolderId] = useState<string | null>(null);
  const router = useRouter();
  const queryClient = useQueryClient();

  // Use React Query to fetch folders
  const { 
    data: folders = [], 
    isLoading: foldersLoading,
    error: foldersError 
  } = useQuery({
    queryKey: ['folders', currentFolderId],
    queryFn: async () => {
      const data = await getFolders(currentFolderId);
      if ("error" in data) {
        throw new Error(data.error);
      }
      return data;
    },
    enabled: !!session?.user?.accessToken,
  });

  // Use React Query to fetch files
  const { 
    data: files = [], 
    isLoading: filesLoading,
    error: filesError 
  } = useQuery({
    queryKey: ['files', currentFolderId],
    queryFn: async () => {
      const data = await getFiles(currentFolderId);
      if ("error" in data) {
        throw new Error(data.error);
      }
      return data;
    },
    enabled: !!session?.user?.accessToken,
  });

  // Combine loading and error states
  const isLoading = foldersLoading || filesLoading;
  const error = foldersError || filesError;

  const handleBackClick = () => {
    setCurrentFolderId(null);
  };

  const handleFolderClick = (folderId: string) => {
    router.push(`/folder/${folderId}`);
  };

  const handleFolderDelete = async (folderId: string) => {
    try {
      const result = await deleteFolder(folderId);
      
      if (result.success) {
        // Invalidate and refetch folders to update the UI
        queryClient.invalidateQueries({ queryKey: ['folders'] });
        toast.success(result.message || "Folder deleted successfully");
      } else {
        toast.error(result.message || "Failed to delete folder");
      }
    } catch (error) {
      console.error("Error deleting folder:", error);
      toast.error("An unexpected error occurred while deleting the folder");
    }
  };

  const handleFolderRename = async (folderId: string, newName: string) => {
    try {
      const result = await renameFolder(folderId, newName);
      
      if (result.success) {
        // Invalidate and refetch folders to update the UI
        queryClient.invalidateQueries({ queryKey: ['folders'] });
        toast.success(result.message || "Folder renamed successfully");
      } else {
        toast.error(result.message || "Failed to rename folder");
      }
    } catch (error) {
      console.error("Error renaming folder:", error);
      toast.error("An unexpected error occurred while renaming the folder");
    }
  };

  return (
    <main className="flex-1 overflow-y-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-semibold">{currentFolderId ? "Folder Contents" : "My Drive"}</h2>
        {currentFolderId && (
          <button onClick={handleBackClick} className="px-4 py-2 bg-gray-100 rounded-md hover:bg-gray-200 transition-colors">
            Back to My Drive
          </button>
        )}
      </div>

      <ContentListing 
        folders={folders}
        files={files}
        isLoading={isLoading}
        error={error}
        onFolderClick={handleFolderClick}
        onFolderDelete={handleFolderDelete}
        onFolderRename={handleFolderRename}
      />
    </main>
  );
}
