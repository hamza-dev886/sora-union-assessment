import prisma from "../config/prisma";
import { v4 as uuidv4 } from "uuid";

export const uploadFile = async (file: Express.Multer.File, userId: string, folderId?: string) => {
  const fileId = uuidv4();
  const key = `${userId}/${fileId}-${file.originalname}`;
  const mockUrl = `/api/files/${fileId}/view`;

  const newFile = await prisma.file.create({
    data: {
      name: file.originalname,
      size: file.size,
      type: file.mimetype,
      key: key,
      url: mockUrl,
      ownerId: userId,
      folderId: folderId || null,
    },
  });

  return newFile;
};

export const getFiles = async (userId: string, folderId?: string) => {
  const files = await prisma.file.findMany({
    where: {
      ownerId: userId,
      folderId: folderId || null,
    },
  });

  return files;
};

export const getFile = async (fileId: string, userId: string) => {
  const file = await prisma.file.findFirst({
    where: {
      id: fileId,
      ownerId: userId,
    },
  });

  if (!file) {
    throw new Error("File not found");
  }

  return file;
};

export const renameFile = async (fileId: string, userId: string, name: string) => {
  const file = await prisma.file.findFirst({
    where: {
      id: fileId,
      ownerId: userId,
    },
  });

  if (!file) {
    throw new Error("File not found");
  }

  const updatedFile = await prisma.file.update({
    where: {
      id: fileId,
    },
    data: {
      name,
    },
  });

  return updatedFile;
};

export const deleteFile = async (fileId: string, userId: string) => {
  const file = await prisma.file.findFirst({
    where: {
      id: fileId,
      ownerId: userId,
    },
  });

  if (!file) {
    throw new Error("File not found");
  }

  await prisma.file.delete({
    where: {
      id: fileId,
    },
  });

  return { success: true };
};
