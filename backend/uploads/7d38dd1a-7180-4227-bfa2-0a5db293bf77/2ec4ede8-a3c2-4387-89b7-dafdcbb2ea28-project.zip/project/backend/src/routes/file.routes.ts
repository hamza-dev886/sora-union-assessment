import { Router, RequestHandler } from 'express';
import * as fileController from '../controllers/file.controller';
import { authenticateToken } from '../middleware/auth.middleware';
import multer from 'multer';

const router = Router();
const upload = multer({ storage: multer.memoryStorage() });

// Use the RequestHandler type to satisfy TypeScript
router.post('/upload', authenticateToken as RequestHandler, upload.single('file'), fileController.uploadFile as RequestHandler);
router.get('/', authenticateToken as RequestHandler, fileController.getFiles as RequestHandler);
router.get('/:id', authenticateToken as RequestHandler, fileController.getFile as RequestHandler);
router.patch('/:id/rename', authenticateToken as RequestHandler, fileController.renameFile as RequestHandler);
router.delete('/:id', authenticateToken as RequestHandler, fileController.deleteFile as RequestHandler);

export default router;