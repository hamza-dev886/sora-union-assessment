import mongoose, { Schema, Document } from 'mongoose';

export interface IFile extends Document {
  name: string;
  size: number;
  type: string;
  key: string;
  url: string;
  owner: mongoose.Types.ObjectId;
  folder: mongoose.Types.ObjectId | null;
  createdAt: Date;
  updatedAt: Date;
}

const FileSchema: Schema = new Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  size: {
    type: Number,
    required: true
  },
  type: {
    type: String,
    required: true
  },
  key: {
    type: String,
    required: true,
    unique: true
  },
  url: {
    type: String,
    required: true
  },
  owner: {
    type: Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  folder: {
    type: Schema.Types.ObjectId,
    ref: 'Folder',
    default: null
  }
}, {
  timestamps: true
});

export default mongoose.model<IFile>('File', FileSchema);