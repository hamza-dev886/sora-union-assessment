import { Request, Response } from 'express';
import * as fileService from '../services/file.service';

export const uploadFile = async (req: Request, res: Response) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No file uploaded' });
    }

    const { folderId } = req.body;
    const file = await fileService.uploadFile(req.file, req.user.userId, folderId);

    res.status(201).json({
      message: 'File metadata stored successfully (demo mode - file not actually stored)',
      file
    });
  } catch (error: any) {
    console.error('File upload error:', error);
    res.status(500).json({ message: 'Server error during file metadata storage' });
  }
};

export const getFiles = async (req: Request, res: Response) => {
  try {
    const folderId = req.query.folderId as string | undefined;
    const files = await fileService.getFiles(req.user.userId, folderId);
    
    res.json(files);
  } catch (error: any) {
    console.error('Get files error:', error);
    res.status(500).json({ message: 'Server error while fetching files' });
  }
};

export const getFile = async (req: Request, res: Response) => {
  try {
    const file = await fileService.getFile(req.params.id, req.user.userId);
    res.json(file);
  } catch (error: any) {
    console.error('Get file error:', error);
    if (error.message === 'File not found') {
      return res.status(404).json({ message: 'File not found' });
    }
    res.status(500).json({ message: 'Server error while fetching file' });
  }
};

export const renameFile = async (req: Request, res: Response) => {
  try {
    const { name } = req.body;
    
    if (!name) {
      return res.status(400).json({ message: 'Name is required' });
    }
    
    const file = await fileService.renameFile(req.params.id, req.user.userId, name);
    
    res.json({
      message: 'File renamed successfully',
      file
    });
  } catch (error: any) {
    console.error('Rename file error:', error);
    if (error.message === 'File not found') {
      return res.status(404).json({ message: 'File not found' });
    }
    res.status(500).json({ message: 'Server error while renaming file' });
  }
};

export const deleteFile = async (req: Request, res: Response) => {
  try {
    await fileService.deleteFile(req.params.id, req.user.userId);
    res.json({ message: 'File metadata deleted successfully' });
  } catch (error: any) {
    console.error('Delete file error:', error);
    if (error.message === 'File not found') {
      return res.status(404).json({ message: 'File not found' });
    }
    res.status(500).json({ message: 'Server error while deleting file' });
  }
};

export const moveFile = async (req: Request, res: Response) => {
  try {
    const { folderId } = req.body;
    const file = await fileService.moveFile(req.params.id, req.user.userId, folderId);
    
    res.json({
      message: 'File moved successfully',
      file
    });
  } catch (error: any) {
    console.error('Move file error:', error);
    if (error.message === 'File not found') {
      return res.status(404).json({ message: 'File not found' });
    }
    res.status(500).json({ message: 'Server error while moving file' });
  }
};